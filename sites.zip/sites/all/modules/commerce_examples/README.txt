Commerce Examples is a place for demonstrations of Drupal Commerce APIs. 

If you have additional examples you'd like to contribute, please provide them
as patches in the issue queue at 
http://drupal.org/project/issues/commerce_examples.