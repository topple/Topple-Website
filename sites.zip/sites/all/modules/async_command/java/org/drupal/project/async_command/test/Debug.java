package org.drupal.project.async_command.test;

public class Debug {

    public static void main(String[] args) {
        long a = 1;
        Long b = null;
        a = b;
        System.out.println(a);

        byte[] bt = null;

    }
}
