package org.drupal.project.async_command.exception;

public class CommandParseException extends DrupletException {
    //@Override
    public CommandParseException(String msg) {
        super(msg);
    }

}
